import {
  BallEvent,
  BatterStats,
  BowlerStats,
  ExtraType,
  FallOfWicket,
  InningsComputedStats,
  InningsData,
  Match,
  MatchFormat,
  MatchResult,
  MatchTeamSnapshot,
  Partnership,
  Player,
  Team,
  Tournament,
  TournamentStandingRow,
  WicketInfo,
} from '../types/cricket';

export function createId(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function formatOvers(legalBalls: number): string {
  const overs = Math.floor(legalBalls / 6);
  const balls = legalBalls % 6;
  return `${overs}.${balls}`;
}

export function getTeamSnapshot(match: Match, side: 'teamA' | 'teamB'): MatchTeamSnapshot {
  return side === 'teamA' ? match.teams.teamA : match.teams.teamB;
}

export function getPlayerName(snapshot: MatchTeamSnapshot, playerId: string | null | undefined): string {
  if (!playerId) return 'Unknown';
  const found = snapshot.players.find((p) => p.id === playerId);
  return found ? found.name : 'Unknown';
}

export function formatBallBadge(ball: BallEvent): string {
  if (ball.wicket) {
    if (ball.wicket.kind === 'retiredhurt') return 'RH';
    const total = ball.runsOffBat + ball.extraRuns;
    if (ball.extraType === 'wide') return total > 1 ? `W+${total - 1}WD` : 'W+WD';
    if (ball.extraType === 'noball') return total > 1 ? `W+${total - 1}NB` : 'W+NB';
    return ball.runsOffBat > 0 ? `W+${ball.runsOffBat}` : 'W';
  }
  if (ball.extraType === 'wide') {
    return ball.extraRuns > 1 ? `WD+${ball.extraRuns - 1}` : 'WD';
  }
  if (ball.extraType === 'noball') {
    const extraRunPart = ball.runsOffBat + (ball.extraRuns - 1);
    return extraRunPart > 0 ? `NB+${extraRunPart}` : 'NB';
  }
  if (ball.extraType === 'bye') return `B${ball.extraRuns}`;
  if (ball.extraType === 'legbye') return `LB${ball.extraRuns}`;
  return String(ball.runsOffBat);
}

export function getFormatDefaults(format: MatchFormat): {
  oversPerInnings: number | null;
  maxBowlerOvers: number | null;
  followOnThreshold: number;
  label: string;
} {
  switch (format) {
    case 'TEST':
      return { oversPerInnings: null, maxBowlerOvers: null, followOnThreshold: 200, label: 'Test Match' };
    case 'ODI':
      return { oversPerInnings: 50, maxBowlerOvers: 10, followOnThreshold: 0, label: 'ODI (50 Overs)' };
    case 'T20':
      return { oversPerInnings: 20, maxBowlerOvers: 4, followOnThreshold: 0, label: 'T20 (20 Overs)' };
    case 'T10':
      return { oversPerInnings: 10, maxBowlerOvers: 2, followOnThreshold: 0, label: 'T10 (10 Overs)' };
    case 'T5':
      return { oversPerInnings: 5, maxBowlerOvers: 2, followOnThreshold: 0, label: 'T5 (5 Overs)' };
    case 'CUSTOM':
      return { oversPerInnings: 15, maxBowlerOvers: 3, followOnThreshold: 0, label: 'Custom Overs' };
    case 'PRACTICE':
      return { oversPerInnings: 10, maxBowlerOvers: null, followOnThreshold: 0, label: 'Practice Match' };
  }
}

export function computeInningsStats(
  innings: InningsData,
  battingTeam: MatchTeamSnapshot,
  bowlingTeam: MatchTeamSnapshot
): InningsComputedStats {
  const xiBatPlayers: Player[] = battingTeam.playingXI
    .map((id) => battingTeam.players.find((p) => p.id === id))
    .filter((p): p is Player => Boolean(p));

  // Fallback if playingXI is empty
  const activeBatPool = xiBatPlayers.length > 0 ? xiBatPlayers : battingTeam.players;
  const xiBowlPlayers: Player[] = bowlingTeam.playingXI
    .map((id) => bowlingTeam.players.find((p) => p.id === id))
    .filter((p): p is Player => Boolean(p));
  const activeBowlPool = xiBowlPlayers.length > 0 ? xiBowlPlayers : bowlingTeam.players;

  const batterMap = new Map<string, BatterStats>();
  const batterOrder: string[] = [];

  const ensureBatter = (id: string): BatterStats => {
    let entry = batterMap.get(id);
    if (!entry) {
      const p = battingTeam.players.find((pl) => pl.id === id);
      entry = {
        playerId: id,
        name: p ? p.name : 'Unknown',
        isCaptain: battingTeam.captainId === id,
        isKeeper: battingTeam.keeperId === id,
        runs: 0,
        balls: 0,
        fours: 0,
        sixes: 0,
        strikeRate: 0,
        batted: true,
        isOut: false,
        isRetiredHurt: false,
        dismissalText: 'not out',
      };
      batterMap.set(id, entry);
      batterOrder.push(id);
    }
    return entry;
  };

  const bowlerMap = new Map<string, BowlerStats>();
  const bowlerOrder: string[] = [];

  const ensureBowler = (id: string): BowlerStats => {
    let entry = bowlerMap.get(id);
    if (!entry) {
      const p = bowlingTeam.players.find((pl) => pl.id === id);
      entry = {
        playerId: id,
        name: p ? p.name : 'Unknown',
        legalBalls: 0,
        oversDisplay: '0.0',
        maidens: 0,
        runs: 0,
        wickets: 0,
        economy: 0,
        wides: 0,
        noballs: 0,
      };
      bowlerMap.set(id, entry);
      bowlerOrder.push(id);
    }
    return entry;
  };

  let totalRuns = 0;
  let wickets = 0;
  let legalBalls = 0;
  let byes = 0;
  let legByes = 0;
  let wides = 0;
  let noBalls = 0;

  const fallOfWickets: FallOfWicket[] = [];
  const partnerships: Partnership[] = [];

  let pRuns = 0;
  let pBalls = 0;
  let pBatter1 = innings.balls[0]?.strikerId || innings.strikerId || '';
  let pBatter2 = innings.balls[0]?.nonStrikerId || innings.nonStrikerId || '';

  // Track maiden overs: key = `${overNumber}:${bowlerId}` -> { legalCount, bowlerRuns }
  const overMaidenTracker = new Map<number, { bowlerId: string; legalCount: number; runsCharged: number }>();

  for (const ball of innings.balls) {
    const striker = ensureBatter(ball.strikerId);
    ensureBatter(ball.nonStrikerId);
    const bowler = ensureBowler(ball.bowlerId);

    // If a retired hurt batter returned, reset retiredHurt flag
    if (striker.isRetiredHurt && !striker.isOut) {
      striker.isRetiredHurt = false;
      striker.dismissalText = 'not out';
    }

    const ballTotalRuns = ball.runsOffBat + ball.extraRuns;
    totalRuns += ballTotalRuns;

    // Extras accounting
    if (ball.extraType === 'wide') wides += ball.extraRuns;
    else if (ball.extraType === 'noball') {
      noBalls += 1;
      // If additional extras beyond the 1 NB penalty were byes/legbyes, we still count extraRuns in extras
      if (ball.extraRuns > 1) byes += ball.extraRuns - 1;
    } else if (ball.extraType === 'bye') byes += ball.extraRuns;
    else if (ball.extraType === 'legbye') legByes += ball.extraRuns;

    // Batter runs & balls faced
    striker.runs += ball.runsOffBat;
    if (ball.runsOffBat === 4) striker.fours += 1;
    if (ball.runsOffBat === 6) striker.sixes += 1;
    if (ball.extraType !== 'wide') {
      striker.balls += 1;
    }

    // Legal ball count
    if (ball.isLegal) {
      legalBalls += 1;
      bowler.legalBalls += 1;
      pBalls += 1;
    }

    // Bowler runs conceded (bat runs + wides + no-balls; byes & leg-byes are NOT charged to bowler)
    let bowlerBallRuns = ball.runsOffBat;
    if (ball.extraType === 'wide') {
      bowlerBallRuns += ball.extraRuns;
      bowler.wides += 1;
    } else if (ball.extraType === 'noball') {
      bowlerBallRuns += 1; // Only the 1 NB penalty + bat runs are charged to bowler
      bowler.noballs += 1;
    }
    bowler.runs += bowlerBallRuns;

    // Maiden over tracker
    const tracker = overMaidenTracker.get(ball.overNumber) || {
      bowlerId: ball.bowlerId,
      legalCount: 0,
      runsCharged: 0,
    };
    if (ball.isLegal) tracker.legalCount += 1;
    tracker.runsCharged += bowlerBallRuns;
    overMaidenTracker.set(ball.overNumber, tracker);

    // Partnership runs
    pRuns += ballTotalRuns;
    if (!pBatter1) pBatter1 = ball.strikerId;
    if (!pBatter2) pBatter2 = ball.nonStrikerId;

    // Wicket handling
    if (ball.wicket) {
      const w = ball.wicket;
      const dismissed = ensureBatter(w.dismissedBatsmanId);
      const bowlerName = getPlayerName(bowlingTeam, ball.bowlerId);
      const fielderName = w.fielderId ? getPlayerName(bowlingTeam, w.fielderId) : '';

      if (w.kind === 'retiredhurt') {
        dismissed.isRetiredHurt = true;
        dismissed.dismissalText = 'retired hurt';
      } else {
        wickets += 1;
        dismissed.isOut = true;
        switch (w.kind) {
          case 'bowled':
            dismissed.dismissalText = `b ${bowlerName}`;
            bowler.wickets += 1;
            break;
          case 'caught':
            dismissed.dismissalText =
              w.fielderId === ball.bowlerId
                ? `c & b ${bowlerName}`
                : `c ${fielderName || 'sub'} b ${bowlerName}`;
            bowler.wickets += 1;
            break;
          case 'lbw':
            dismissed.dismissalText = `lbw b ${bowlerName}`;
            bowler.wickets += 1;
            break;
          case 'stumped':
            dismissed.dismissalText = `st ${fielderName || 'wk'} b ${bowlerName}`;
            bowler.wickets += 1;
            break;
          case 'hitwicket':
            dismissed.dismissalText = `hit wicket b ${bowlerName}`;
            bowler.wickets += 1;
            break;
          case 'runout':
            dismissed.dismissalText = fielderName ? `run out (${fielderName})` : 'run out';
            break;
        }

        fallOfWickets.push({
          wicketNumber: wickets,
          runs: totalRuns,
          oversDisplay: formatOvers(legalBalls),
          playerId: dismissed.playerId,
          playerName: dismissed.name,
        });

        partnerships.push({
          wicketIndex: wickets,
          batter1Id: pBatter1,
          batter1Name: getPlayerName(battingTeam, pBatter1),
          batter2Id: pBatter2,
          batter2Name: getPlayerName(battingTeam, pBatter2),
          runs: pRuns,
          balls: pBalls,
          isCurrent: false,
        });

        pRuns = 0;
        pBalls = 0;
        const survivorId =
          w.dismissedBatsmanId === ball.strikerId ? ball.nonStrikerId : ball.strikerId;
        pBatter1 = survivorId;
        pBatter2 = '';
      }
    }
  }

  // Ensure current crease batters are included even if they haven't faced a ball yet
  if (innings.strikerId) ensureBatter(innings.strikerId);
  if (innings.nonStrikerId) ensureBatter(innings.nonStrikerId);
  if (innings.currentBowlerId) ensureBowler(innings.currentBowlerId);

  // Add current unbroken partnership if innings is active or ended with not-out pair
  if (innings.strikerId && innings.nonStrikerId && (pRuns > 0 || pBalls > 0 || !innings.isCompleted)) {
    const b1 = pBatter1 || innings.strikerId;
    const b2 = pBatter2 || (b1 === innings.strikerId ? innings.nonStrikerId : innings.strikerId);
    if (b1 && b2 && b1 !== b2) {
      partnerships.push({
        wicketIndex: wickets + 1,
        batter1Id: b1,
        batter1Name: getPlayerName(battingTeam, b1),
        batter2Id: b2,
        batter2Name: getPlayerName(battingTeam, b2),
        runs: pRuns,
        balls: pBalls,
        isCurrent: !innings.isCompleted,
      });
    }
  }

  // Finalize maidens
  for (const [, info] of overMaidenTracker.entries()) {
    if (info.legalCount === 6 && info.runsCharged === 0) {
      const b = bowlerMap.get(info.bowlerId);
      if (b) b.maidens += 1;
    }
  }

  // Finalize rates
  const batters: BatterStats[] = batterOrder.map((id) => {
    const b = batterMap.get(id)!;
    b.strikeRate = b.balls > 0 ? Number(((b.runs / b.balls) * 100).toFixed(1)) : 0;
    return b;
  });

  const bowlers: BowlerStats[] = bowlerOrder.map((id) => {
    const bw = bowlerMap.get(id)!;
    bw.oversDisplay = formatOvers(bw.legalBalls);
    bw.economy = bw.legalBalls > 0 ? Number((bw.runs / (bw.legalBalls / 6)).toFixed(2)) : 0;
    return bw;
  });

  const didNotBat = activeBatPool.filter((p) => !batterMap.has(p.id));
  const currentOverIndex = Math.floor(legalBalls / 6);
  const currentOverBalls = innings.balls.filter((b) => b.overNumber === currentOverIndex);

  const runRate = legalBalls > 0 ? Number((totalRuns / (legalBalls / 6)).toFixed(2)) : 0;

  // Keep activeBowlPool referenced cleanly if needed
  void activeBowlPool;

  return {
    totalRuns,
    wickets,
    legalBalls,
    oversDisplay: formatOvers(legalBalls),
    runRate,
    extras: {
      total: byes + legByes + wides + noBalls,
      byes,
      legByes,
      wides,
      noBalls,
    },
    batters,
    bowlers,
    fallOfWickets,
    partnerships,
    didNotBat,
    currentOverBalls,
  };
}

export interface MatchComputedOverview {
  inningsStats: InningsComputedStats[];
  teamATotalRuns: number;
  teamBTotalRuns: number;
  target: number | null;
  runsNeeded: number | null;
  ballsRemaining: number | null;
  requiredRunRate: number | null;
  statusLine: string;
  isFollowOnEligible: boolean;
}

export function computeMatchOverview(match: Match): MatchComputedOverview {
  const inningsStats = match.innings.map((inn) =>
    computeInningsStats(
      inn,
      getTeamSnapshot(match, inn.battingTeamSide),
      getTeamSnapshot(match, inn.bowlingTeamSide)
    )
  );

  let teamATotalRuns = 0;
  let teamBTotalRuns = 0;
  match.innings.forEach((inn, idx) => {
    const r = inningsStats[idx].totalRuns;
    if (inn.battingTeamSide === 'teamA') teamATotalRuns += r;
    else teamBTotalRuns += r;
  });

  const currentInn = match.innings[match.currentInningsIndex];
  const currentStats = inningsStats[match.currentInningsIndex];

  let target: number | null = null;
  let runsNeeded: number | null = null;
  let ballsRemaining: number | null = null;
  let requiredRunRate: number | null = null;
  let statusLine = '';
  let isFollowOnEligible = false;

  if (match.status === 'completed' && match.result) {
    statusLine = match.result.summary;
  } else if (match.format !== 'TEST') {
    if (match.currentInningsIndex === 0) {
      const batName = getTeamSnapshot(match, currentInn.battingTeamSide).shortName;
      statusLine =
        match.oversPerInnings !== null
          ? `${batName} batting · ${match.oversPerInnings} over match`
          : `${batName} batting · Practice Match`;
    } else if (match.currentInningsIndex === 1) {
      const inn1Runs = inningsStats[0].totalRuns;
      target = inn1Runs + 1;
      runsNeeded = Math.max(0, target - currentStats.totalRuns);
      const batName = getTeamSnapshot(match, currentInn.battingTeamSide).shortName;
      if (match.oversPerInnings !== null) {
        ballsRemaining = Math.max(0, match.oversPerInnings * 6 - currentStats.legalBalls);
        requiredRunRate =
          ballsRemaining > 0 && runsNeeded > 0
            ? Number((runsNeeded / (ballsRemaining / 6)).toFixed(2))
            : 0;
        statusLine = `${batName} need ${runsNeeded} run${runsNeeded === 1 ? '' : 's'} from ${ballsRemaining} ball${ballsRemaining === 1 ? '' : 's'}`;
      } else {
        statusLine = `${batName} need ${runsNeeded} run${runsNeeded === 1 ? '' : 's'} to win`;
      }
    }
  } else {
    // Test Match logic across up to 4 innings
    const innCount = match.innings.length;
    const batSide = currentInn.battingTeamSide;
    const bowlSide = currentInn.bowlingTeamSide;
    const batName = getTeamSnapshot(match, batSide).shortName;
    const bowlName = getTeamSnapshot(match, bowlSide).shortName;

    const batSum = batSide === 'teamA' ? teamATotalRuns : teamBTotalRuns;
    const bowlSum = bowlSide === 'teamA' ? teamATotalRuns : teamBTotalRuns;

    if (innCount === 1) {
      statusLine = `Day ${match.testState?.day || 1} · 1st Innings · ${batName} batting`;
    } else if (innCount === 2) {
      const diff = bowlSum - batSum;
      if (currentInn.isCompleted && diff >= match.followOnThreshold && !match.testState?.followOnResolved) {
        isFollowOnEligible = true;
      }
      if (diff > 0) statusLine = `${batName} trail by ${diff} run${diff === 1 ? '' : 's'}`;
      else if (diff < 0) statusLine = `${batName} lead by ${Math.abs(diff)} run${Math.abs(diff) === 1 ? '' : 's'}`;
      else statusLine = 'Scores are level';
    } else if (innCount === 3) {
      const diff = batSum - bowlSum;
      if (diff > 0) statusLine = `${batName} lead by ${diff} run${diff === 1 ? '' : 's'}`;
      else if (diff < 0) statusLine = `${batName} trail by ${Math.abs(diff)} run${Math.abs(diff) === 1 ? '' : 's'}`;
      else statusLine = 'Scores are level';
    } else if (innCount === 4) {
      const prevBatRunsBefore4th = batSum - currentStats.totalRuns;
      target = bowlSum - prevBatRunsBefore4th + 1;
      runsNeeded = Math.max(0, target - currentStats.totalRuns);
      statusLine = `${batName} need ${runsNeeded} run${runsNeeded === 1 ? '' : 's'} to win`;
    }
    void bowlName;
  }

  return {
    inningsStats,
    teamATotalRuns,
    teamBTotalRuns,
    target,
    runsNeeded,
    ballsRemaining,
    requiredRunRate,
    statusLine,
    isFollowOnEligible,
  };
}

export interface BallInput {
  runsOffBat: number;
  extraType: ExtraType;
  extraRuns: number; // total extra runs (1+ for wide/noball, 1+ for bye/legbye, 0 for none)
  wicket?: WicketInfo;
}

/**
 * Recomputes strike, over numbers, and innings completion sequentially from the ball log,
 * so both applying a ball, undoing a ball, and editing any historical ball stay 100% consistent!
 */
export function recomputeInningsState(
  match: Match,
  inningsIndex: number,
  initialStrikerId: string | null,
  initialNonStrikerId: string | null
): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const inn = nextMatch.innings[inningsIndex];
  const battingTeam = getTeamSnapshot(nextMatch, inn.battingTeamSide);
  const bowlingTeam = getTeamSnapshot(nextMatch, inn.bowlingTeamSide);

  let legalBalls = 0;
  let totalRuns = 0;
  let wickets = 0;
  let striker = initialStrikerId || inn.balls[0]?.strikerId || inn.strikerId;
  let nonStriker = initialNonStrikerId || inn.balls[0]?.nonStrikerId || inn.nonStrikerId;
  let lastBowler: string | null = inn.balls[0]?.bowlerId || inn.currentBowlerId;
  let prevBowler: string | null = null;

  for (let i = 0; i < inn.balls.length; i++) {
    const b = inn.balls[i];
    const overNum = Math.floor(legalBalls / 6);
    const isLegal = b.extraType !== 'wide' && b.extraType !== 'noball';
    b.overNumber = overNum;
    b.isLegal = isLegal;

    if (isLegal) {
      legalBalls += 1;
      b.ballInOver = ((legalBalls - 1) % 6) + 1;
    } else {
      b.ballInOver = (legalBalls % 6) + 1;
    }

    totalRuns += b.runsOffBat + b.extraRuns;
    if (b.wicket && b.wicket.kind !== 'retiredhurt') {
      wickets += 1;
    }

    if (b.bowlerId !== lastBowler && lastBowler) {
      prevBowler = lastBowler;
    }
    lastBowler = b.bowlerId;

    // Strike rotation for next ball
    let curStriker = b.strikerId;
    let curNonStriker = b.nonStrikerId;

    // Running runs that cause crossing
    let runningRuns = b.runsOffBat;
    if (b.extraType === 'bye' || b.extraType === 'legbye') {
      runningRuns += b.extraRuns;
    } else if (b.extraType === 'wide' || b.extraType === 'noball') {
      // Subtract the 1 penalty run to find actual running runs (when not off bat)
      runningRuns += Math.max(0, b.extraRuns - 1);
    }

    if (runningRuns % 2 === 1) {
      const tmp = curStriker;
      curStriker = curNonStriker;
      curNonStriker = tmp;
    }

    // End of over swaps strike
    if (isLegal && legalBalls % 6 === 0) {
      const tmp = curStriker;
      curStriker = curNonStriker;
      curNonStriker = tmp;
    }

    striker = curStriker;
    nonStriker = curNonStriker;
  }

  // If the last ball was a wicket, check if next ball has already picked the replacement (during edits)
  // Otherwise mark needsNewBatter if wickets < playersPerSide - 1
  const lastBall = inn.balls[inn.balls.length - 1];
  const maxWickets = Math.max(1, nextMatch.playersPerSide - 1);
  const allOut = wickets >= maxWickets;
  const oversDone =
    nextMatch.oversPerInnings !== null && legalBalls >= nextMatch.oversPerInnings * 6;

  // Check if chasing target reached
  let targetAchieved = false;
  if (nextMatch.format !== 'TEST' && inningsIndex === 1) {
    const firstInnStats = computeInningsStats(
      nextMatch.innings[0],
      getTeamSnapshot(nextMatch, nextMatch.innings[0].battingTeamSide),
      getTeamSnapshot(nextMatch, nextMatch.innings[0].bowlingTeamSide)
    );
    if (totalRuns >= firstInnStats.totalRuns + 1) {
      targetAchieved = true;
    }
  } else if (nextMatch.format === 'TEST' && inningsIndex === 3) {
    const overview = computeMatchOverview(nextMatch);
    if (overview.target !== null && totalRuns >= overview.target) {
      targetAchieved = true;
    }
  }

  if (targetAchieved) {
    inn.isCompleted = true;
    inn.closureReason = 'target_achieved';
  } else if (allOut) {
    inn.isCompleted = true;
    inn.closureReason = 'all_out';
  } else if (oversDone) {
    inn.isCompleted = true;
    inn.closureReason = 'overs_completed';
  } else if (!inn.isDeclared && inn.closureReason !== 'manual') {
    inn.isCompleted = false;
    inn.closureReason = undefined;
  }

  // Handle striker/nonStriker after wicket on last ball
  if (lastBall && lastBall.wicket && !inn.isCompleted) {
    if (lastBall.wicket.dismissedBatsmanId === striker) striker = null;
    if (lastBall.wicket.dismissedBatsmanId === nonStriker) nonStriker = null;
    inn.needsNewBatter = striker === null || nonStriker === null;
  } else {
    inn.needsNewBatter = false;
  }

  // Handle end-of-over bowler prompt
  if (lastBall && lastBall.isLegal && legalBalls % 6 === 0 && !inn.isCompleted) {
    inn.previousBowlerId = lastBall.bowlerId;
    inn.currentBowlerId = null;
    inn.needsNewBowler = true;
  } else {
    inn.previousBowlerId = prevBowler;
    if (!inn.currentBowlerId && lastBowler) {
      inn.currentBowlerId = lastBowler;
    }
    inn.needsNewBowler = false;
  }

  inn.strikerId = striker;
  inn.nonStrikerId = nonStriker;

  void battingTeam;
  void bowlingTeam;

  // Evaluate automatic match completion
  return evaluateMatchCompletion(nextMatch);
}

export function evaluateMatchCompletion(match: Match): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const overview = computeMatchOverview(nextMatch);

  if (nextMatch.format !== 'TEST') {
    if (nextMatch.innings.length === 2 && nextMatch.innings[1].isCompleted) {
      const inn0 = nextMatch.innings[0];
      const inn1 = nextMatch.innings[1];
      const r0 = overview.inningsStats[0].totalRuns;
      const r1 = overview.inningsStats[1].totalRuns;
      const w1 = overview.inningsStats[1].wickets;
      const t0 = getTeamSnapshot(nextMatch, inn0.battingTeamSide);
      const t1 = getTeamSnapshot(nextMatch, inn1.battingTeamSide);
      const maxWickets = Math.max(1, nextMatch.playersPerSide - 1);

      let result: MatchResult;
      if (r1 > r0) {
        const wLeft = maxWickets - w1;
        result = {
          winnerSide: inn1.battingTeamSide,
          summary: `${t1.name} won by ${wLeft} wicket${wLeft === 1 ? '' : 's'}`,
          marginText: `${wLeft} wicket${wLeft === 1 ? '' : 's'}`,
        };
      } else if (r0 > r1) {
        const diff = r0 - r1;
        result = {
          winnerSide: inn0.battingTeamSide,
          summary: `${t0.name} won by ${diff} run${diff === 1 ? '' : 's'}`,
          marginText: `${diff} run${diff === 1 ? '' : 's'}`,
        };
      } else {
        result = {
          winnerSide: 'tie',
          summary: 'Match Tied',
          marginText: 'Scores level',
        };
      }
      nextMatch.status = 'completed';
      nextMatch.result = result;
    } else {
      nextMatch.status = 'in_progress';
      nextMatch.result = undefined;
    }
    return nextMatch;
  }

  // Test match completion evaluation
  const innCount = nextMatch.innings.length;
  if (innCount === 3 && nextMatch.innings[2].isCompleted) {
    // Check if the team that batted only once still leads -> Innings victory!
    const teamAInningsCount = nextMatch.innings.filter((i) => i.battingTeamSide === 'teamA').length;
    const teamBInningsCount = nextMatch.innings.filter((i) => i.battingTeamSide === 'teamB').length;
    const oneInnSide = teamAInningsCount === 1 ? 'teamA' : teamBInningsCount === 1 ? 'teamB' : null;
    if (oneInnSide) {
      const twoInnSide = oneInnSide === 'teamA' ? 'teamB' : 'teamA';
      const oneSum = oneInnSide === 'teamA' ? overview.teamATotalRuns : overview.teamBTotalRuns;
      const twoSum = twoInnSide === 'teamA' ? overview.teamATotalRuns : overview.teamBTotalRuns;
      if (oneSum > twoSum) {
        const winner = getTeamSnapshot(nextMatch, oneInnSide);
        const margin = oneSum - twoSum;
        nextMatch.status = 'completed';
        nextMatch.result = {
          winnerSide: oneInnSide,
          summary: `${winner.name} won by an innings and ${margin} run${margin === 1 ? '' : 's'}`,
          marginText: `Innings & ${margin} runs`,
        };
        return nextMatch;
      }
    }
  }

  if (innCount === 4 && nextMatch.innings[3].isCompleted) {
    const inn4 = nextMatch.innings[3];
    const chaseSide = inn4.battingTeamSide;
    const defendSide = inn4.bowlingTeamSide;
    const chaseSum = chaseSide === 'teamA' ? overview.teamATotalRuns : overview.teamBTotalRuns;
    const defendSum = defendSide === 'teamA' ? overview.teamATotalRuns : overview.teamBTotalRuns;
    const chaseTeam = getTeamSnapshot(nextMatch, chaseSide);
    const defendTeam = getTeamSnapshot(nextMatch, defendSide);
    const maxWickets = Math.max(1, nextMatch.playersPerSide - 1);

    if (chaseSum > defendSum) {
      const wLeft = maxWickets - overview.inningsStats[3].wickets;
      nextMatch.status = 'completed';
      nextMatch.result = {
        winnerSide: chaseSide,
        summary: `${chaseTeam.name} won by ${wLeft} wicket${wLeft === 1 ? '' : 's'}`,
        marginText: `${wLeft} wicket${wLeft === 1 ? '' : 's'}`,
      };
    } else if (defendSum > chaseSum) {
      const margin = defendSum - chaseSum;
      nextMatch.status = 'completed';
      nextMatch.result = {
        winnerSide: defendSide,
        summary: `${defendTeam.name} won by ${margin} run${margin === 1 ? '' : 's'}`,
        marginText: `${margin} run${margin === 1 ? '' : 's'}`,
      };
    } else {
      nextMatch.status = 'completed';
      nextMatch.result = {
        winnerSide: 'tie',
        summary: 'Test Match Tied',
        marginText: 'Scores level',
      };
    }
    return nextMatch;
  }

  if (nextMatch.result?.winnerSide !== 'draw') {
    nextMatch.status = 'in_progress';
    nextMatch.result = undefined;
  }
  return nextMatch;
}

export function applyBallToMatch(match: Match, input: BallInput): Match {
  const idx = match.currentInningsIndex;
  const inn = match.innings[idx];
  if (!inn || inn.isCompleted || !inn.strikerId || !inn.nonStrikerId || !inn.currentBowlerId) {
    return match;
  }

  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const targetInn = nextMatch.innings[idx];
  const initialStriker = targetInn.balls[0]?.strikerId || targetInn.strikerId;
  const initialNonStriker = targetInn.balls[0]?.nonStrikerId || targetInn.nonStrikerId;

  const newBall: BallEvent = {
    id: createId('ball'),
    overNumber: 0,
    ballInOver: 1,
    strikerId: targetInn.strikerId!,
    nonStrikerId: targetInn.nonStrikerId!,
    bowlerId: targetInn.currentBowlerId!,
    runsOffBat: input.runsOffBat,
    extraType: input.extraType,
    extraRuns: input.extraRuns,
    isLegal: input.extraType !== 'wide' && input.extraType !== 'noball',
    wicket: input.wicket,
    timestamp: Date.now(),
  };

  targetInn.balls.push(newBall);
  nextMatch.updatedAt = Date.now();

  const updated = recomputeInningsState(nextMatch, idx, initialStriker, initialNonStriker);

  // If end-of-over AND wicket fell simultaneously, ensure needsNewBatter is preserved
  const updatedInn = updated.innings[idx];
  if (newBall.wicket && !updatedInn.isCompleted) {
    if (updatedInn.strikerId === null || updatedInn.nonStrikerId === null) {
      updatedInn.needsNewBatter = true;
    }
  }

  return updated;
}

export function undoLastBallInMatch(match: Match): Match {
  const idx = match.currentInningsIndex;
  const inn = match.innings[idx];
  if (!inn || inn.balls.length === 0) return match;

  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const targetInn = nextMatch.innings[idx];
  const removed = targetInn.balls.pop()!;
  targetInn.isDeclared = false;
  targetInn.isCompleted = false;
  targetInn.closureReason = undefined;
  nextMatch.status = 'in_progress';
  nextMatch.result = undefined;
  nextMatch.updatedAt = Date.now();

  if (targetInn.balls.length === 0) {
    targetInn.strikerId = removed.strikerId;
    targetInn.nonStrikerId = removed.nonStrikerId;
    targetInn.currentBowlerId = removed.bowlerId;
    targetInn.needsNewBatter = false;
    targetInn.needsNewBowler = false;
    return nextMatch;
  }

  const initialStriker = targetInn.balls[0].strikerId;
  const initialNonStriker = targetInn.balls[0].nonStrikerId;
  const recomputed = recomputeInningsState(nextMatch, idx, initialStriker, initialNonStriker);

  // Ensure bowler stays set to the bowler of the removed ball if we just undid ball 6 of an over
  const recInn = recomputed.innings[idx];
  if (!recInn.currentBowlerId) {
    recInn.currentBowlerId = removed.bowlerId;
    recInn.needsNewBowler = false;
  }
  return recomputed;
}

export function editBallInMatch(
  match: Match,
  inningsIndex: number,
  ballId: string,
  patch: Partial<Pick<BallEvent, 'runsOffBat' | 'extraType' | 'extraRuns' | 'wicket'>>
): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const targetInn = nextMatch.innings[inningsIndex];
  if (!targetInn) return match;

  const ball = targetInn.balls.find((b) => b.id === ballId);
  if (!ball) return match;

  if (patch.runsOffBat !== undefined) ball.runsOffBat = patch.runsOffBat;
  if (patch.extraType !== undefined) ball.extraType = patch.extraType;
  if (patch.extraRuns !== undefined) ball.extraRuns = patch.extraRuns;
  if ('wicket' in patch) ball.wicket = patch.wicket;

  nextMatch.updatedAt = Date.now();
  const initialStriker = targetInn.balls[0]?.strikerId || targetInn.strikerId;
  const initialNonStriker = targetInn.balls[0]?.nonStrikerId || targetInn.nonStrikerId;
  return recomputeInningsState(nextMatch, inningsIndex, initialStriker, initialNonStriker);
}

export function startNextInnings(match: Match, battingSide: 'teamA' | 'teamB'): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const bowlingSide = battingSide === 'teamA' ? 'teamB' : 'teamA';
  const nextNum = (nextMatch.innings.length + 1) as 1 | 2 | 3 | 4;
  if (nextNum > 4) return match;

  nextMatch.innings.push({
    inningsNumber: nextNum,
    battingTeamSide: battingSide,
    bowlingTeamSide: bowlingSide,
    balls: [],
    strikerId: null,
    nonStrikerId: null,
    currentBowlerId: null,
    previousBowlerId: null,
    isDeclared: false,
    isCompleted: false,
    needsNewBatter: false,
    needsNewBowler: false,
  });
  nextMatch.currentInningsIndex = nextMatch.innings.length - 1;
  nextMatch.updatedAt = Date.now();
  return nextMatch;
}

export function declareCurrentInnings(match: Match): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const inn = nextMatch.innings[nextMatch.currentInningsIndex];
  if (!inn) return match;
  inn.isDeclared = true;
  inn.isCompleted = true;
  inn.closureReason = 'declared';
  inn.needsNewBatter = false;
  inn.needsNewBowler = false;
  nextMatch.updatedAt = Date.now();
  return evaluateMatchCompletion(nextMatch);
}

export function drawTestMatch(match: Match): Match {
  const nextMatch: Match = JSON.parse(JSON.stringify(match));
  const inn = nextMatch.innings[nextMatch.currentInningsIndex];
  if (inn) {
    inn.isCompleted = true;
    inn.closureReason = 'manual';
  }
  nextMatch.status = 'completed';
  nextMatch.result = {
    winnerSide: 'draw',
    summary: 'Match Drawn',
    marginText: 'Draw',
  };
  nextMatch.updatedAt = Date.now();
  return nextMatch;
}

export function generateShareableScorecard(match: Match): string {
  const overview = computeMatchOverview(match);
  const lines: string[] = [];
  lines.push(`CRIC X — ${match.title}`);
  lines.push(`Format: ${getFormatDefaults(match.format).label}`);
  if (match.result) {
    lines.push(`Result: ${match.result.summary}`);
  } else {
    lines.push(`Status: ${overview.statusLine}`);
  }
  lines.push('');

  match.innings.forEach((inn, i) => {
    const batTeam = getTeamSnapshot(match, inn.battingTeamSide);
    const stats = overview.inningsStats[i];
    lines.push(
      `--- ${batTeam.name} (${inn.inningsNumber}${inn.inningsNumber === 1 ? 'st' : inn.inningsNumber === 2 ? 'nd' : inn.inningsNumber === 3 ? 'rd' : 'th'} Inn): ${stats.totalRuns}/${stats.wickets} (${stats.oversDisplay} ov) ---`
    );
    stats.batters.forEach((b) => {
      lines.push(
        `${b.name}: ${b.runs} (${b.balls}) [4s:${b.fours} 6s:${b.sixes} SR:${b.strikeRate}] - ${b.dismissalText}`
      );
    });
    lines.push(
      `Extras: ${stats.extras.total} (b ${stats.extras.byes}, lb ${stats.extras.legByes}, w ${stats.extras.wides}, nb ${stats.extras.noBalls})`
    );
    lines.push('Bowling:');
    stats.bowlers.forEach((bw) => {
      lines.push(
        `${bw.name}: ${bw.oversDisplay}-${bw.maidens}-${bw.runs}-${bw.wickets} (Econ ${bw.economy})`
      );
    });
    lines.push('');
  });

  lines.push('Scored offline with CRIC X');
  return lines.join('\n');
}

export function computeTournamentStandings(
  tournament: Tournament,
  teams: Team[],
  matches: Match[]
): TournamentStandingRow[] {
  const rows = new Map<string, TournamentStandingRow>();

  const runsFor = new Map<string, number>();
  const oversFaced = new Map<string, number>();
  const runsAgainst = new Map<string, number>();
  const oversBowled = new Map<string, number>();

  for (const tid of tournament.teamIds) {
    const t = teams.find((x) => x.id === tid);
    rows.set(tid, {
      teamId: tid,
      teamName: t?.name || 'Team',
      shortName: t?.shortName || 'TM',
      played: 0,
      won: 0,
      lost: 0,
      tied: 0,
      noResult: 0,
      points: 0,
      nrr: 0,
    });
    runsFor.set(tid, 0);
    oversFaced.set(tid, 0);
    runsAgainst.set(tid, 0);
    oversBowled.set(tid, 0);
  }

  for (const fix of tournament.fixtures) {
    if (!fix.matchId) continue;
    const m = matches.find((x) => x.id === fix.matchId);
    if (!m || m.status !== 'completed' || !m.result) continue;

    const rA = rows.get(m.teams.teamA.teamId);
    const rB = rows.get(m.teams.teamB.teamId);
    if (!rA || !rB) continue;

    rA.played += 1;
    rB.played += 1;

    if (m.result.winnerSide === 'teamA') {
      rA.won += 1;
      rA.points += 2;
      rB.lost += 1;
    } else if (m.result.winnerSide === 'teamB') {
      rB.won += 1;
      rB.points += 2;
      rA.lost += 1;
    } else if (m.result.winnerSide === 'tie') {
      rA.tied += 1;
      rB.tied += 1;
      rA.points += 1;
      rB.points += 1;
    } else {
      rA.noResult += 1;
      rB.noResult += 1;
      rA.points += 1;
      rB.points += 1;
    }

    // ICC NRR calculation: if all out, full quota overs are counted as faced
    const overview = computeMatchOverview(m);
    const quotaOvers = m.oversPerInnings || 20;
    const maxWickets = Math.max(1, m.playersPerSide - 1);

    m.innings.forEach((inn, idx) => {
      const st = overview.inningsStats[idx];
      const batTid = getTeamSnapshot(m, inn.battingTeamSide).teamId;
      const bowlTid = getTeamSnapshot(m, inn.bowlingTeamSide).teamId;
      const effectiveOvers =
        st.wickets >= maxWickets ? quotaOvers : st.legalBalls / 6;

      runsFor.set(batTid, (runsFor.get(batTid) || 0) + st.totalRuns);
      oversFaced.set(batTid, (oversFaced.get(batTid) || 0) + effectiveOvers);
      runsAgainst.set(bowlTid, (runsAgainst.get(bowlTid) || 0) + st.totalRuns);
      oversBowled.set(bowlTid, (oversBowled.get(bowlTid) || 0) + effectiveOvers);
    });
  }

  return Array.from(rows.values())
    .map((row) => {
      const rf = runsFor.get(row.teamId) || 0;
      const of = oversFaced.get(row.teamId) || 0;
      const ra = runsAgainst.get(row.teamId) || 0;
      const ob = oversBowled.get(row.teamId) || 0;
      const forRate = of > 0 ? rf / of : 0;
      const againstRate = ob > 0 ? ra / ob : 0;
      row.nrr = Number((forRate - againstRate).toFixed(3));
      return row;
    })
    .sort((a, b) => b.points - a.points || b.nrr - a.nrr || b.won - a.won);
}
