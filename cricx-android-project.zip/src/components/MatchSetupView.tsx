import React, { useState } from 'react';
import { Play, Plus, ArrowLeft, Check } from 'lucide-react';
import { Match, MatchFormat, MatchTeamSnapshot, Team } from '../types/cricket';
import { createId, getFormatDefaults } from '../engine/cricketEngine';
import { createQuickTeam } from '../engine/storage';

interface MatchSetupViewProps {
  initialFormat: MatchFormat;
  teams: Team[];
  onSaveTeams: (teams: Team[]) => void;
  onStartMatch: (match: Match) => void;
  onBack: () => void;
}

const FORMATS: { value: MatchFormat; label: string }[] = [
  { value: 'TEST', label: 'Test Match' },
  { value: 'ODI', label: 'ODI (50 Ov)' },
  { value: 'T20', label: 'T20 (20 Ov)' },
  { value: 'T10', label: 'T10 (10 Ov)' },
  { value: 'T5', label: 'T5 (5 Ov)' },
  { value: 'CUSTOM', label: 'Custom Overs' },
  { value: 'PRACTICE', label: 'Practice Match' },
];

export const MatchSetupView: React.FC<MatchSetupViewProps> = ({
  initialFormat,
  teams,
  onSaveTeams,
  onStartMatch,
  onBack,
}) => {
  const defaults = getFormatDefaults(initialFormat);
  const [format, setFormat] = useState<MatchFormat>(initialFormat);
  const [oversPerInnings, setOversPerInnings] = useState<string>(
    defaults.oversPerInnings !== null ? String(defaults.oversPerInnings) : '20'
  );
  const [unlimitedOvers, setUnlimitedOvers] = useState<boolean>(
    initialFormat === 'TEST'
  );
  const [playersPerSide, setPlayersPerSide] = useState<number>(11);
  const [maxBowlerOvers, setMaxBowlerOvers] = useState<string>(
    defaults.maxBowlerOvers !== null ? String(defaults.maxBowlerOvers) : ''
  );
  const [followOnThreshold, setFollowOnThreshold] = useState<number>(200);

  const [teamAId, setTeamAId] = useState<string>(teams[0]?.id || '');
  const [teamBId, setTeamBId] = useState<string>(teams[1]?.id || teams[0]?.id || '');
  const [tossWinner, setTossWinner] = useState<'teamA' | 'teamB'>('teamA');
  const [tossDecision, setTossDecision] = useState<'bat' | 'bowl'>('bat');
  const [matchTitle, setMatchTitle] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Quick inline team creator modal
  const [quickModalOpen, setQuickModalOpen] = useState(false);
  const [quickTargetSide, setQuickTargetSide] = useState<'A' | 'B'>('A');
  const [quickName, setQuickName] = useState('');
  const [quickShort, setQuickShort] = useState('');
  const [quickPlayersText, setQuickPlayersText] = useState(
    'Player 1, Player 2, Player 3, Player 4, Player 5, Player 6, Player 7, Player 8, Player 9, Player 10, Player 11'
  );

  // Per-match XI overrides
  const teamA = teams.find((t) => t.id === teamAId) || null;
  const teamB = teams.find((t) => t.id === teamBId) || null;

  const [xiA, setXiA] = useState<string[] | null>(null);
  const [xiB, setXiB] = useState<string[] | null>(null);

  const effectiveXiA =
    xiA ||
    (teamA
      ? (teamA.defaultPlayingXI.length > 0
          ? teamA.defaultPlayingXI
          : teamA.players.map((p) => p.id)
        ).slice(0, playersPerSide)
      : []);

  const effectiveXiB =
    xiB ||
    (teamB
      ? (teamB.defaultPlayingXI.length > 0
          ? teamB.defaultPlayingXI
          : teamB.players.map((p) => p.id)
        ).slice(0, playersPerSide)
      : []);

  const handleFormatChange = (nextFmt: MatchFormat) => {
    setFormat(nextFmt);
    const d = getFormatDefaults(nextFmt);
    if (nextFmt === 'TEST') {
      setUnlimitedOvers(true);
      setMaxBowlerOvers('');
      setFollowOnThreshold(200);
    } else {
      setUnlimitedOvers(false);
      setOversPerInnings(String(d.oversPerInnings ?? 15));
      setMaxBowlerOvers(d.maxBowlerOvers !== null ? String(d.maxBowlerOvers) : '');
    }
  };

  const handleQuickCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickName.trim()) return;
    const names = quickPlayersText
      .split(/[,\n]/)
      .map((s) => s.trim())
      .filter(Boolean);
    const newTeam = createQuickTeam(
      quickName,
      quickShort || quickName.slice(0, 3),
      names.length >= 2 ? names : ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5']
    );
    const next = [newTeam, ...teams];
    onSaveTeams(next);
    if (quickTargetSide === 'A') {
      setTeamAId(newTeam.id);
      setXiA(null);
    } else {
      setTeamBId(newTeam.id);
      setXiB(null);
    }
    setQuickName('');
    setQuickShort('');
    setQuickModalOpen(false);
  };

  const togglePlayerInXi = (side: 'A' | 'B', playerId: string) => {
    const current = side === 'A' ? effectiveXiA : effectiveXiB;
    const exists = current.includes(playerId);
    const next = exists
      ? current.filter((id) => id !== playerId)
      : current.length < playersPerSide
      ? [...current, playerId]
      : current;
    if (side === 'A') setXiA(next);
    else setXiB(next);
  };

  const buildSnapshot = (team: Team, selectedXi: string[]): MatchTeamSnapshot => {
    const xi = selectedXi.filter((id) => team.players.some((p) => p.id === id));
    const subs = team.players.filter((p) => !xi.includes(p.id)).map((p) => p.id);
    return {
      teamId: team.id,
      name: team.name,
      shortName: team.shortName,
      players: team.players,
      playingXI: xi,
      substitutes: subs,
      captainId: team.defaultCaptainId,
      keeperId: team.defaultKeeperId,
    };
  };

  const handleCreateMatch = () => {
    setError('');
    if (!teamA || !teamB) {
      setError('Please select both teams before starting.');
      return;
    }
    if (teamA.id === teamB.id) {
      setError('Team A and Team B must be different teams.');
      return;
    }
    if (effectiveXiA.length < 2 || effectiveXiB.length < 2) {
      setError('Each team needs at least 2 selected players to start scoring.');
      return;
    }

    const parsedOvers = unlimitedOvers
      ? null
      : Math.max(1, Math.min(99, parseInt(oversPerInnings || '20', 10) || 20));
    const parsedMaxBowler =
      !unlimitedOvers && maxBowlerOvers.trim() !== ''
        ? Math.max(1, parseInt(maxBowlerOvers, 10) || 1)
        : null;

    const firstBattingSide: 'teamA' | 'teamB' =
      tossDecision === 'bat'
        ? tossWinner
        : tossWinner === 'teamA'
        ? 'teamB'
        : 'teamA';
    const firstBowlingSide: 'teamA' | 'teamB' =
      firstBattingSide === 'teamA' ? 'teamB' : 'teamA';

    const effectivePlayersCount = Math.min(
      playersPerSide,
      Math.max(effectiveXiA.length, effectiveXiB.length)
    );

    const now = Date.now();
    const match: Match = {
      id: createId('match'),
      title: matchTitle.trim() || `${teamA.shortName} vs ${teamB.shortName}`,
      format,
      oversPerInnings: format === 'TEST' ? null : parsedOvers,
      maxBowlerOvers: format === 'TEST' ? null : parsedMaxBowler,
      playersPerSide: effectivePlayersCount,
      followOnThreshold: format === 'TEST' ? followOnThreshold : 0,
      teams: {
        teamA: buildSnapshot(teamA, effectiveXiA),
        teamB: buildSnapshot(teamB, effectiveXiB),
      },
      toss: {
        winnerSide: tossWinner,
        decision: tossDecision,
      },
      innings: [
        {
          inningsNumber: 1,
          battingTeamSide: firstBattingSide,
          bowlingTeamSide: firstBowlingSide,
          balls: [],
          strikerId: null,
          nonStrikerId: null,
          currentBowlerId: null,
          previousBowlerId: null,
          isDeclared: false,
          isCompleted: false,
          needsNewBatter: false,
          needsNewBowler: false,
        },
      ],
      currentInningsIndex: 0,
      testState:
        format === 'TEST'
          ? {
              day: 1,
              session: 'Morning',
              followOnOffered: false,
              followOnEnforced: false,
              followOnResolved: false,
            }
          : undefined,
      status: 'in_progress',
      createdAt: now,
      updatedAt: now,
    };

    onStartMatch(match);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 border-b border-white/15 pb-4">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] rounded-xl border border-white/15 flex items-center justify-center text-white hover:bg-white/10"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Match Setup</h1>
          <p className="text-xs text-neutral-400">Configure rules, squads, and toss</p>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-white bg-neutral-900 px-4 py-3 text-sm text-white">
          {error}
        </div>
      )}

      {/* Format Selection */}
      <section className="rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white">1. Match Format & Rules</h2>
        <div className="flex flex-wrap gap-2">
          {FORMATS.map((f) => {
            const active = format === f.value;
            return (
              <button
                key={f.value}
                type="button"
                onClick={() => handleFormatChange(f.value)}
                className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-medium border transition whitespace-nowrap ${
                  active
                    ? 'bg-white text-black border-white font-semibold'
                    : 'bg-black text-neutral-300 border-white/15 hover:border-white/40'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          <div>
            <label className="block text-xs text-neutral-400 mb-1.5">Match Title (Optional)</label>
            <input
              type="text"
              value={matchTitle}
              onChange={(e) => setMatchTitle(e.target.value)}
              placeholder={
                teamA && teamB ? `${teamA.shortName} vs ${teamB.shortName}` : 'Sunday Clash'
              }
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm focus:outline-none focus:border-white"
            />
          </div>

          {format !== 'TEST' && (
            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">
                Overs per Innings
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={99}
                  disabled={unlimitedOvers}
                  value={oversPerInnings}
                  onChange={(e) => setOversPerInnings(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm font-mono disabled:opacity-40 focus:outline-none focus:border-white"
                />
                {format === 'PRACTICE' && (
                  <button
                    type="button"
                    onClick={() => setUnlimitedOvers(!unlimitedOvers)}
                    className={`min-h-[44px] px-3 rounded-xl text-xs border whitespace-nowrap ${
                      unlimitedOvers
                        ? 'bg-white text-black border-white font-semibold'
                        : 'bg-black text-neutral-300 border-white/20'
                    }`}
                  >
                    Unlimited
                  </button>
                )}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs text-neutral-400 mb-1.5">Players per Side</label>
            <select
              value={playersPerSide}
              onChange={(e) => {
                setPlayersPerSide(Number(e.target.value));
                setXiA(null);
                setXiB(null);
              }}
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm font-mono focus:outline-none focus:border-white"
            >
              {[2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((n) => (
                <option key={n} value={n}>
                  {n} Players
                </option>
              ))}
            </select>
          </div>

          {format === 'TEST' ? (
            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">
                Follow-On Lead Rule
              </label>
              <select
                value={followOnThreshold}
                onChange={(e) => setFollowOnThreshold(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm font-mono focus:outline-none focus:border-white"
              >
                <option value={200}>200 Runs (5-Day Standard)</option>
                <option value={150}>150 Runs (3-4 Day)</option>
                <option value={100}>100 Runs (2-Day)</option>
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">
                Max Overs per Bowler
              </label>
              <input
                type="number"
                min={1}
                max={50}
                placeholder="No limit"
                value={maxBowlerOvers}
                onChange={(e) => setMaxBowlerOvers(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm font-mono focus:outline-none focus:border-white"
              />
            </div>
          )}
        </div>
      </section>

      {/* Team Selection */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {(['A', 'B'] as const).map((side) => {
          const team = side === 'A' ? teamA : teamB;
          const selectedId = side === 'A' ? teamAId : teamBId;
          const xi = side === 'A' ? effectiveXiA : effectiveXiB;

          return (
            <div
              key={side}
              className="rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-4"
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-white">
                  {side === 'A' ? '2. Home / Team A' : '3. Away / Team B'}
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    setQuickTargetSide(side);
                    setQuickModalOpen(true);
                  }}
                  className="min-h-[36px] px-3 rounded-lg border border-white/20 text-xs text-white hover:bg-white/10 inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Quick Team</span>
                </button>
              </div>

              <select
                value={selectedId}
                onChange={(e) => {
                  if (side === 'A') {
                    setTeamAId(e.target.value);
                    setXiA(null);
                  } else {
                    setTeamBId(e.target.value);
                    setXiB(null);
                  }
                }}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm focus:outline-none focus:border-white"
              >
                <option value="">Select Team</option>
                {teams.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.shortName}) — {t.players.length} players
                  </option>
                ))}
              </select>

              {team && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>
                      Playing Squad ({xi.length}/{playersPerSide} selected)
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const top = team.players.slice(0, playersPerSide).map((p) => p.id);
                        if (side === 'A') setXiA(top);
                        else setXiB(top);
                      }}
                      className="text-white hover:underline"
                    >
                      Auto-pick {Math.min(playersPerSide, team.players.length)}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1">
                    {team.players.map((p) => {
                      const active = xi.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => togglePlayerInXi(side, p.id)}
                          className={`min-h-[40px] px-3 rounded-lg text-left text-xs border flex items-center justify-between gap-2 transition ${
                            active
                              ? 'bg-white text-black border-white font-medium'
                              : 'bg-black text-neutral-400 border-white/10 hover:border-white/30'
                          }`}
                        >
                          <span className="truncate">{p.name}</span>
                          {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </section>

      {/* Toss & Launch */}
      <section className="rounded-2xl bg-neutral-950 border border-white/15 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-white">4. Toss & Decision</h2>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setTossWinner('teamA')}
              className={`min-h-[42px] px-4 rounded-xl text-xs border transition ${
                tossWinner === 'teamA'
                  ? 'bg-white text-black border-white font-semibold'
                  : 'bg-black text-neutral-300 border-white/15'
              }`}
            >
              {teamA ? `${teamA.shortName} won toss` : 'Team A won toss'}
            </button>
            <button
              type="button"
              onClick={() => setTossWinner('teamB')}
              className={`min-h-[42px] px-4 rounded-xl text-xs border transition ${
                tossWinner === 'teamB'
                  ? 'bg-white text-black border-white font-semibold'
                  : 'bg-black text-neutral-300 border-white/15'
              }`}
            >
              {teamB ? `${teamB.shortName} won toss` : 'Team B won toss'}
            </button>
            <span className="text-neutral-500 text-xs px-1">elected to</span>
            <button
              type="button"
              onClick={() => setTossDecision('bat')}
              className={`min-h-[42px] px-4 rounded-xl text-xs border transition ${
                tossDecision === 'bat'
                  ? 'bg-white text-black border-white font-semibold'
                  : 'bg-black text-neutral-300 border-white/15'
              }`}
            >
              Bat First
            </button>
            <button
              type="button"
              onClick={() => setTossDecision('bowl')}
              className={`min-h-[42px] px-4 rounded-xl text-xs border transition ${
                tossDecision === 'bowl'
                  ? 'bg-white text-black border-white font-semibold'
                  : 'bg-black text-neutral-300 border-white/15'
              }`}
            >
              Bowl First
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCreateMatch}
          className="min-h-[52px] px-7 rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200 active:scale-[0.98] transition inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Start Match</span>
        </button>
      </section>

      {/* Quick Create Team Modal */}
      {quickModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <form
            onSubmit={handleQuickCreate}
            className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4"
          >
            <h3 className="text-lg font-bold text-white">
              Quick Create Team {quickTargetSide}
            </h3>
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="block text-xs text-neutral-400 mb-1">Team Name</label>
                <input
                  type="text"
                  required
                  value={quickName}
                  onChange={(e) => setQuickName(e.target.value)}
                  placeholder="City XI"
                  className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Code</label>
                <input
                  type="text"
                  maxLength={4}
                  value={quickShort}
                  onChange={(e) => setQuickShort(e.target.value.toUpperCase())}
                  placeholder="CTY"
                  className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm font-mono uppercase"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">
                Players (comma or line separated)
              </label>
              <textarea
                rows={4}
                value={quickPlayersText}
                onChange={(e) => setQuickPlayersText(e.target.value)}
                className="w-full p-3 rounded-xl bg-black border border-white/20 text-white text-xs leading-relaxed"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setQuickModalOpen(false)}
                className="min-h-[44px] px-4 rounded-xl border border-white/20 text-white text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-xl bg-white text-black text-sm font-semibold"
              >
                Create & Select
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
