import React, { useRef, useState } from 'react';
import { X, Smartphone, HardDrive, ShieldCheck, Download, Upload } from 'lucide-react';
import {
  CricXBackupPayload,
  exportBackupData,
  importBackupData,
} from '../engine/storage';

interface OfflineGuideModalProps {
  open: boolean;
  onClose: () => void;
  onDataImported: (payload: CricXBackupPayload) => void;
}

export const OfflineGuideModal: React.FC<OfflineGuideModalProps> = ({
  open,
  onClose,
  onDataImported,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMsg, setStatusMsg] = useState<string>('');

  if (!open) return null;

  const handleExport = () => {
    const payload = exportBackupData();
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cricx-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatusMsg('Backup file downloaded.');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      const imported = importBackupData(content);
      if (imported) {
        onDataImported(imported);
        setStatusMsg(
          `Restored ${imported.teams.length} teams, ${imported.matches.length} matches, and ${imported.tournaments.length} tournaments.`
        );
      } else {
        setStatusMsg('Invalid CRIC X backup file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <div className="w-full max-w-lg rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-5 text-white max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <h2 className="font-display text-2xl font-bold tracking-wide">
            CRIC X — Offline App & Backup
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-white"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-sm text-neutral-300 leading-relaxed">
          <div className="flex gap-3">
            <Smartphone className="w-5 h-5 text-white shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-white">Install on Android</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Open CRIC X in Chrome on Android and tap Install App (or Chrome Menu → Add to Home screen / Install app). It launches fullscreen with the black-and-white CRIC X icon and runs offline.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <HardDrive className="w-5 h-5 text-white shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-white">100% Local Offline Persistence</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Every ball, scorecard, team squad, and tournament table saves automatically on your device. Unfinished matches resume immediately when reopened.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <ShieldCheck className="w-5 h-5 text-white shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-white">Zero Accounts & Zero Tracking</h3>
              <p className="text-xs text-neutral-400 mt-1">
                No login, no OTP, no subscription, and no internet connection required for scoring.
              </p>
            </div>
          </div>
        </div>

        {/* Offline Backup Export & Restore */}
        <div className="pt-4 border-t border-white/10 space-y-3">
          <div className="text-xs font-mono text-neutral-400">DEVICE BACKUP & RESTORE</div>
          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={handleExport}
              className="min-h-[44px] px-3 rounded-xl border border-white/25 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Export Backup</span>
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[44px] px-3 rounded-xl border border-white/25 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>Restore Backup</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
          {statusMsg && (
            <p className="text-xs text-white font-mono">{statusMsg}</p>
          )}
        </div>

        {/* Android Studio Project & Offline Source ZIP */}
        <div className="pt-4 border-t border-white/10 space-y-2.5">
          <div className="text-xs font-mono text-neutral-400">ANDROID STUDIO PROJECT & SOURCE ZIP</div>
          <a
            href="./cricx-android-project.zip"
            download="cricx-android-project.zip"
            className="w-full min-h-[44px] px-4 rounded-xl border border-white/25 text-white text-xs font-semibold hover:bg-white/10 inline-flex items-center justify-center gap-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Download Android Project (.zip)</span>
          </a>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full min-h-[46px] rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200 transition"
        >
          Back to CRIC X
        </button>
      </div>
    </div>
  );
};
