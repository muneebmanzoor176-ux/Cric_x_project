import React, { useState } from 'react';
import { Play, Trash2, Share2, ClipboardList, Check } from 'lucide-react';
import { Match } from '../types/cricket';
import {
  computeMatchOverview,
  generateShareableScorecard,
  getFormatDefaults,
} from '../engine/cricketEngine';

interface HistoryViewProps {
  matches: Match[];
  onResumeMatch: (matchId: string) => void;
  onViewScorecard: (matchId: string) => void;
  onDeleteMatch: (matchId: string) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  matches,
  onResumeMatch,
  onViewScorecard,
  onDeleteMatch,
}) => {
  const [filter, setFilter] = useState<'all' | 'in_progress' | 'completed'>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [sharedId, setSharedId] = useState<string | null>(null);

  const filtered = matches.filter((m) => {
    if (filter === 'all') return true;
    return m.status === filter;
  });

  const handleShare = async (match: Match) => {
    const text = generateShareableScorecard(match);
    try {
      if (navigator.share) {
        await navigator.share({ title: match.title, text });
      } else {
        await navigator.clipboard.writeText(text);
      }
    } catch {
      await navigator.clipboard.writeText(text);
    }
    setSharedId(match.id);
    window.setTimeout(() => setSharedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/15 pb-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Match History</h1>
          <p className="text-xs text-neutral-400 mt-1">
            All unfinished and completed matches saved offline on this device.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-white/15 rounded-xl self-start">
          {(
            [
              { id: 'all', label: 'All' },
              { id: 'in_progress', label: 'Unfinished' },
              { id: 'completed', label: 'Completed' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id)}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                filter === tab.id
                  ? 'bg-white text-black font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl bg-neutral-950 border border-dashed border-white/15 p-10 text-center">
          <p className="text-sm text-neutral-300">No matches found in this filter.</p>
          <p className="text-xs text-neutral-500 mt-1">
            Start a match from the Home screen to record scorecards locally.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((m) => {
            const ov = computeMatchOverview(m);
            const isDeleting = confirmDeleteId === m.id;
            return (
              <div
                key={m.id}
                className="rounded-2xl bg-neutral-950 border border-white/15 p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
                    <span>
                      {getFormatDefaults(m.format).label} ·{' '}
                      {m.status === 'in_progress' ? 'Unfinished' : 'Completed'}
                    </span>
                    <span>{new Date(m.updatedAt).toLocaleDateString()}</span>
                  </div>
                  <h2 className="text-lg font-bold text-white">
                    {m.teams.teamA.name} vs {m.teams.teamB.name}
                  </h2>

                  <div className="space-y-1 font-mono text-xs tabular-nums text-neutral-200 pt-1">
                    {m.innings.map((inn, idx) => {
                      const t =
                        inn.battingTeamSide === 'teamA'
                          ? m.teams.teamA.shortName
                          : m.teams.teamB.shortName;
                      const s = ov.inningsStats[idx];
                      return (
                        <div key={inn.inningsNumber} className="flex items-center justify-between">
                          <span>
                            {t} ({inn.inningsNumber}
                            {inn.inningsNumber === 1 ? 'st' : inn.inningsNumber === 2 ? 'nd' : inn.inningsNumber === 3 ? 'rd' : 'th'} Inn)
                          </span>
                          <span className="font-semibold text-white">
                            {s.totalRuns}/{s.wickets}
                            {inn.isDeclared ? 'd' : ''} ({s.oversDisplay} ov)
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  <p className="text-xs text-neutral-300 pt-1">
                    {m.result?.summary || ov.statusLine}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-white/10">
                  {m.status === 'in_progress' && (
                    <button
                      type="button"
                      onClick={() => onResumeMatch(m.id)}
                      className="min-h-[40px] px-3.5 rounded-xl bg-white text-black text-xs font-bold hover:bg-neutral-200 inline-flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Resume</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onViewScorecard(m.id)}
                    className="min-h-[40px] px-3.5 rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center gap-1.5"
                  >
                    <ClipboardList className="w-3.5 h-3.5" />
                    <span>Scorecard</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleShare(m)}
                    className="min-h-[40px] px-3 rounded-xl border border-white/20 text-white text-xs hover:bg-white/10 inline-flex items-center gap-1.5"
                  >
                    {sharedId === m.id ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Share2 className="w-3.5 h-3.5" />
                    )}
                    <span>{sharedId === m.id ? 'Copied' : 'Share'}</span>
                  </button>

                  {isDeleting ? (
                    <div className="flex items-center gap-1.5 ml-auto">
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteMatch(m.id);
                          setConfirmDeleteId(null);
                        }}
                        className="min-h-[40px] px-3 rounded-xl bg-white text-black text-xs font-bold"
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="min-h-[40px] px-2.5 rounded-xl border border-white/20 text-xs text-white"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(m.id)}
                      className="min-h-[40px] min-w-[40px] ml-auto rounded-xl border border-white/15 text-neutral-400 hover:text-white flex items-center justify-center"
                      aria-label="Delete match"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
