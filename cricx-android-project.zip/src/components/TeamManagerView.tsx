import React, { useState } from 'react';
import { Plus, Trash2, Edit3, Check, X, Shield, UserPlus } from 'lucide-react';
import { Player, PlayerRole, Team } from '../types/cricket';
import { createId } from '../engine/cricketEngine';

interface TeamManagerViewProps {
  teams: Team[];
  onSaveTeams: (teams: Team[]) => void;
}

export const TeamManagerView: React.FC<TeamManagerViewProps> = ({ teams, onSaveTeams }) => {
  const [selectedTeamId, setSelectedTeamId] = useState<string>(teams[0]?.id || '');
  const [showCreateTeam, setShowCreateTeam] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamShort, setNewTeamShort] = useState('');
  const [newPlayerName, setNewPlayerName] = useState('');
  const [newPlayerRole, setNewPlayerRole] = useState<PlayerRole>('BAT');
  const [editingTeamInfo, setEditingTeamInfo] = useState(false);
  const [editTeamName, setEditTeamName] = useState('');
  const [editTeamShort, setEditTeamShort] = useState('');
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);
  const [editPlayerName, setEditPlayerName] = useState('');
  const [editPlayerRole, setEditPlayerRole] = useState<PlayerRole>('BAT');
  const [confirmDeleteTeamId, setConfirmDeleteTeamId] = useState<string | null>(null);

  const activeTeam = teams.find((t) => t.id === selectedTeamId) || teams[0] || null;

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTeamName.trim();
    if (!trimmed) return;
    const short =
      newTeamShort.trim().toUpperCase().slice(0, 4) ||
      trimmed
        .split(' ')
        .map((w) => w[0])
        .join('')
        .toUpperCase()
        .slice(0, 3) ||
      'TM';

    const now = Date.now();
    const created: Team = {
      id: createId('team'),
      name: trimmed,
      shortName: short,
      players: [],
      defaultPlayingXI: [],
      createdAt: now,
      updatedAt: now,
    };
    const next = [created, ...teams];
    onSaveTeams(next);
    setSelectedTeamId(created.id);
    setNewTeamName('');
    setNewTeamShort('');
    setShowCreateTeam(false);
  };

  const updateTeam = (updated: Team) => {
    const next = teams.map((t) =>
      t.id === updated.id ? { ...updated, updatedAt: Date.now() } : t
    );
    onSaveTeams(next);
  };

  const handleDeleteTeam = (id: string) => {
    const next = teams.filter((t) => t.id !== id);
    onSaveTeams(next);
    setConfirmDeleteTeamId(null);
    if (selectedTeamId === id) {
      setSelectedTeamId(next[0]?.id || '');
    }
  };

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTeam) return;
    const raw = newPlayerName.trim();
    if (!raw) return;

    // Support comma-separated quick entry too
    const names = raw
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const added: Player[] = names.map((name) => ({
      id: createId('p'),
      name,
      role: newPlayerRole,
    }));

    const nextPlayers = [...activeTeam.players, ...added];
    const nextXI = [...activeTeam.defaultPlayingXI];
    for (const p of added) {
      if (nextXI.length < 11) nextXI.push(p.id);
    }

    updateTeam({
      ...activeTeam,
      players: nextPlayers,
      defaultPlayingXI: nextXI,
      defaultCaptainId: activeTeam.defaultCaptainId || added[0]?.id,
      defaultKeeperId: activeTeam.defaultKeeperId || added[0]?.id,
    });
    setNewPlayerName('');
  };

  const handleSavePlayerEdit = (playerId: string) => {
    if (!activeTeam) return;
    const trimmed = editPlayerName.trim();
    if (!trimmed) return;
    updateTeam({
      ...activeTeam,
      players: activeTeam.players.map((p) =>
        p.id === playerId ? { ...p, name: trimmed, role: editPlayerRole } : p
      ),
    });
    setEditingPlayerId(null);
  };

  const handleDeletePlayer = (playerId: string) => {
    if (!activeTeam) return;
    const nextPlayers = activeTeam.players.filter((p) => p.id !== playerId);
    const nextXI = activeTeam.defaultPlayingXI.filter((id) => id !== playerId);
    updateTeam({
      ...activeTeam,
      players: nextPlayers,
      defaultPlayingXI: nextXI,
      defaultCaptainId:
        activeTeam.defaultCaptainId === playerId ? nextXI[0] : activeTeam.defaultCaptainId,
      defaultKeeperId:
        activeTeam.defaultKeeperId === playerId ? nextXI[0] : activeTeam.defaultKeeperId,
    });
  };

  const togglePlayingXI = (playerId: string) => {
    if (!activeTeam) return;
    const exists = activeTeam.defaultPlayingXI.includes(playerId);
    let nextXI: string[];
    if (exists) {
      nextXI = activeTeam.defaultPlayingXI.filter((id) => id !== playerId);
    } else {
      if (activeTeam.defaultPlayingXI.length >= 11) return;
      nextXI = [...activeTeam.defaultPlayingXI, playerId];
    }
    updateTeam({
      ...activeTeam,
      defaultPlayingXI: nextXI,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/15 pb-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Teams & Squads</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Create teams, manage players, assign Captain (C), Wicketkeeper (WK), Playing XI, and Substitutes.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreateTeam(true)}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200 transition inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Team</span>
        </button>
      </div>

      {showCreateTeam && (
        <form
          onSubmit={handleCreateTeam}
          className="rounded-2xl bg-neutral-950 border border-white/25 p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Create New Team</h2>
            <button
              type="button"
              onClick={() => setShowCreateTeam(false)}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs text-neutral-400 mb-1.5">Team Name</label>
              <input
                type="text"
                value={newTeamName}
                onChange={(e) => setNewTeamName(e.target.value)}
                placeholder="e.g. Royal Challengers"
                required
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm focus:outline-none focus:border-white"
              />
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">Short Code (3-4 chars)</label>
              <input
                type="text"
                value={newTeamShort}
                onChange={(e) => setNewTeamShort(e.target.value.toUpperCase())}
                maxLength={4}
                placeholder="e.g. RCB"
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm font-mono uppercase focus:outline-none focus:border-white"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowCreateTeam(false)}
              className="min-h-[44px] px-4 rounded-xl border border-white/20 text-white text-sm"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200"
            >
              Save Team
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Team List */}
        <div className="lg:col-span-4 space-y-2.5">
          {teams.length === 0 ? (
            <div className="rounded-2xl bg-neutral-950 border border-white/15 p-6 text-center text-sm text-neutral-400">
              No teams yet. Tap New Team to create your first squad.
            </div>
          ) : (
            teams.map((t) => {
              const selected = activeTeam?.id === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setSelectedTeamId(t.id);
                    setEditingTeamInfo(false);
                  }}
                  className={`w-full text-left rounded-2xl p-4 border transition flex items-center justify-between gap-3 ${
                    selected
                      ? 'bg-white text-black border-white'
                      : 'bg-neutral-950 text-white border-white/15 hover:border-white/40'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">{t.name}</div>
                    <div
                      className={`text-xs mt-0.5 font-mono ${
                        selected ? 'text-neutral-700' : 'text-neutral-400'
                      }`}
                    >
                      {t.shortName} · {t.players.length} players · XI ({t.defaultPlayingXI.length})
                    </div>
                  </div>
                  <Shield
                    className={`w-4 h-4 shrink-0 ${
                      selected ? 'text-black' : 'text-neutral-500'
                    }`}
                  />
                </button>
              );
            })
          )}
        </div>

        {/* Active Team Detail */}
        <div className="lg:col-span-8">
          {activeTeam ? (
            <div className="rounded-2xl bg-neutral-950 border border-white/15 p-5 sm:p-6 space-y-6">
              {/* Team Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
                {editingTeamInfo ? (
                  <div className="flex flex-wrap items-center gap-2 flex-1">
                    <input
                      type="text"
                      value={editTeamName}
                      onChange={(e) => setEditTeamName(e.target.value)}
                      className="min-h-[40px] px-3 rounded-lg bg-black border border-white/25 text-white text-sm flex-1 min-w-[160px]"
                    />
                    <input
                      type="text"
                      value={editTeamShort}
                      onChange={(e) => setEditTeamShort(e.target.value.toUpperCase())}
                      maxLength={4}
                      className="min-h-[40px] w-20 px-3 rounded-lg bg-black border border-white/25 text-white text-sm font-mono uppercase"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (editTeamName.trim()) {
                          updateTeam({
                            ...activeTeam,
                            name: editTeamName.trim(),
                            shortName: editTeamShort.trim() || activeTeam.shortName,
                          });
                        }
                        setEditingTeamInfo(false);
                      }}
                      className="min-h-[40px] px-3 rounded-lg bg-white text-black text-xs font-semibold"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-2.5">
                      <h2 className="text-xl font-bold text-white">{activeTeam.name}</h2>
                      <span className="font-mono text-xs text-neutral-400">
                        ({activeTeam.shortName})
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-1">
                      Playing XI: {activeTeam.defaultPlayingXI.length}/11 · Substitutes:{' '}
                      {Math.max(0, activeTeam.players.length - activeTeam.defaultPlayingXI.length)}
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {!editingTeamInfo && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditTeamName(activeTeam.name);
                        setEditTeamShort(activeTeam.shortName);
                        setEditingTeamInfo(true);
                      }}
                      className="min-h-[40px] px-3 rounded-lg border border-white/20 text-xs text-white hover:bg-white/10 inline-flex items-center gap-1.5"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Rename</span>
                    </button>
                  )}
                  {confirmDeleteTeamId === activeTeam.id ? (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleDeleteTeam(activeTeam.id)}
                        className="min-h-[40px] px-3 rounded-lg bg-white text-black text-xs font-semibold"
                      >
                        Confirm Delete
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteTeamId(null)}
                        className="min-h-[40px] px-3 rounded-lg border border-white/20 text-xs text-white"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteTeamId(activeTeam.id)}
                      className="min-h-[40px] px-3 rounded-lg border border-white/20 text-xs text-neutral-300 hover:text-white hover:border-white/40 inline-flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Add Player Form */}
              <form onSubmit={handleAddPlayer} className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={newPlayerName}
                  onChange={(e) => setNewPlayerName(e.target.value)}
                  placeholder="Player name (or comma-separated list)"
                  className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm focus:outline-none focus:border-white"
                />
                <select
                  value={newPlayerRole}
                  onChange={(e) => setNewPlayerRole(e.target.value as PlayerRole)}
                  className="min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:outline-none focus:border-white"
                >
                  <option value="BAT">Batter</option>
                  <option value="BOWL">Bowler</option>
                  <option value="AR">All-Rounder</option>
                  <option value="WK">Wicketkeeper</option>
                </select>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200 inline-flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Add Player</span>
                </button>
              </form>

              {/* Players List */}
              {activeTeam.players.length === 0 ? (
                <div className="py-10 text-center border border-dashed border-white/15 rounded-xl text-sm text-neutral-400">
                  No players in this squad yet. Add players above.
                </div>
              ) : (
                <div className="divide-y divide-white/10">
                  {activeTeam.players.map((p, idx) => {
                    const inXI = activeTeam.defaultPlayingXI.includes(p.id);
                    const isC = activeTeam.defaultCaptainId === p.id;
                    const isWK = activeTeam.defaultKeeperId === p.id;
                    const isEditing = editingPlayerId === p.id;

                    return (
                      <div
                        key={p.id}
                        className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <span className="font-mono text-xs text-neutral-500 w-6 tabular-nums">
                            {idx + 1}.
                          </span>
                          {isEditing ? (
                            <div className="flex flex-wrap items-center gap-2 flex-1">
                              <input
                                type="text"
                                value={editPlayerName}
                                onChange={(e) => setEditPlayerName(e.target.value)}
                                className="min-h-[40px] px-3 rounded-lg bg-black border border-white/30 text-white text-sm flex-1 min-w-[140px]"
                              />
                              <select
                                value={editPlayerRole}
                                onChange={(e) => setEditPlayerRole(e.target.value as PlayerRole)}
                                className="min-h-[40px] px-2.5 rounded-lg bg-black border border-white/30 text-white text-xs"
                              >
                                <option value="BAT">BAT</option>
                                <option value="BOWL">BOWL</option>
                                <option value="AR">AR</option>
                                <option value="WK">WK</option>
                              </select>
                              <button
                                type="button"
                                onClick={() => handleSavePlayerEdit(p.id)}
                                className="min-h-[40px] min-w-[40px] rounded-lg bg-white text-black flex items-center justify-center"
                                aria-label="Save"
                              >
                                <Check className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingPlayerId(null)}
                                className="min-h-[40px] min-w-[40px] rounded-lg border border-white/20 text-white flex items-center justify-center"
                                aria-label="Cancel"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ) : (
                            <div className="min-w-0">
                              <div className="text-sm font-medium text-white truncate">
                                {p.name}{' '}
                                {isC && (
                                  <span className="text-xs font-mono text-neutral-300">(C)</span>
                                )}
                                {isWK && (
                                  <span className="text-xs font-mono text-neutral-300">(WK)</span>
                                )}
                              </div>
                              <div className="text-xs text-neutral-400 font-mono">
                                {p.role} · {inXI ? 'Playing XI' : 'Substitute'}
                              </div>
                            </div>
                          )}
                        </div>

                        {!isEditing && (
                          <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => togglePlayingXI(p.id)}
                              className={`min-h-[38px] px-2.5 rounded-lg text-xs font-medium border transition ${
                                inXI
                                  ? 'bg-white text-black border-white font-semibold'
                                  : 'bg-black text-neutral-400 border-white/15 hover:text-white'
                              }`}
                            >
                              {inXI ? 'XI' : 'SUB'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                updateTeam({
                                  ...activeTeam,
                                  defaultCaptainId: isC ? undefined : p.id,
                                })
                              }
                              className={`min-h-[38px] px-2.5 rounded-lg text-xs font-mono border transition ${
                                isC
                                  ? 'bg-white text-black border-white font-bold'
                                  : 'bg-black text-neutral-400 border-white/15 hover:text-white'
                              }`}
                              title="Set Captain"
                            >
                              C
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                updateTeam({
                                  ...activeTeam,
                                  defaultKeeperId: isWK ? undefined : p.id,
                                })
                              }
                              className={`min-h-[38px] px-2.5 rounded-lg text-xs font-mono border transition ${
                                isWK
                                  ? 'bg-white text-black border-white font-bold'
                                  : 'bg-black text-neutral-400 border-white/15 hover:text-white'
                              }`}
                              title="Set Wicketkeeper"
                            >
                              WK
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingPlayerId(p.id);
                                setEditPlayerName(p.name);
                                setEditPlayerRole(p.role);
                              }}
                              className="min-h-[38px] min-w-[38px] rounded-lg border border-white/15 text-neutral-300 hover:text-white flex items-center justify-center"
                              aria-label={`Edit ${p.name}`}
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeletePlayer(p.id)}
                              className="min-h-[38px] min-w-[38px] rounded-lg border border-white/15 text-neutral-400 hover:text-white flex items-center justify-center"
                              aria-label={`Delete ${p.name}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
