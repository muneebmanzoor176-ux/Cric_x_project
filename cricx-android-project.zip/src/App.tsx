import React, { useEffect, useState } from 'react';
import { Home, Users, Trophy, History } from 'lucide-react';
import { Match, MatchFormat, Team, Tournament } from './types/cricket';
import {
  deleteMatchById,
  loadMatches,
  loadTeams,
  loadTournaments,
  saveTeams,
  saveTournaments,
  upsertMatch,
} from './engine/storage';
import { CricXLogo } from './components/CricXLogo';
import { SplashScreen } from './components/SplashScreen';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineGuideModal } from './components/OfflineGuideModal';
import { HomeView } from './components/HomeView';
import { TeamManagerView } from './components/TeamManagerView';
import { MatchSetupView } from './components/MatchSetupView';
import { LiveScoringView } from './components/LiveScoringView';
import { ScorecardView } from './components/ScorecardView';
import { HistoryView } from './components/HistoryView';
import { TournamentView } from './components/TournamentView';

type AppView =
  | { name: 'home' }
  | { name: 'teams' }
  | { name: 'tournaments' }
  | { name: 'history' }
  | { name: 'setup'; format: MatchFormat }
  | { name: 'live'; matchId: string }
  | { name: 'scorecard'; matchId: string };

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [view, setView] = useState<AppView>({ name: 'home' });
  const [teams, setTeams] = useState<Team[]>(() => loadTeams());
  const [matches, setMatches] = useState<Match[]>(() => loadMatches());
  const [tournaments, setTournaments] = useState<Tournament[]>(() => loadTournaments());
  const [guideOpen, setGuideOpen] = useState(false);

  // Android / Browser Back-Button Navigation Integration
  const navigateTo = (next: AppView) => {
    setView(next);
    try {
      window.history.pushState({ view: next }, '');
    } catch {
      // Ignore in restricted iframe contexts
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  useEffect(() => {
    try {
      window.history.replaceState({ view: { name: 'home' } }, '');
    } catch {
      // Ignore
    }
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.view) {
        setView(event.state.view as AppView);
      } else {
        setView({ name: 'home' });
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleSaveTeams = (next: Team[]) => {
    setTeams(next);
    saveTeams(next);
  };

  const handleSaveTournaments = (next: Tournament[]) => {
    setTournaments(next);
    saveTournaments(next);
  };

  const handleUpdateMatch = (updated: Match) => {
    const nextMatches = upsertMatch(updated);
    setMatches(nextMatches);

    // Sync tournament fixture status if linked
    if (updated.tournamentId && updated.fixtureId) {
      const nextTourneys = tournaments.map((t) => {
        if (t.id !== updated.tournamentId) return t;
        return {
          ...t,
          updatedAt: Date.now(),
          fixtures: t.fixtures.map((f) => {
            if (f.id !== updated.fixtureId) return f;
            return {
              ...f,
              matchId: updated.id,
              status: (updated.status === 'completed' ? 'completed' : 'in_progress') as
                | 'completed'
                | 'in_progress',
              resultSummary: updated.result?.summary,
            };
          }),
        };
      });
      handleSaveTournaments(nextTourneys);
    }
  };

  const handleDeleteMatch = (matchId: string) => {
    setMatches(deleteMatchById(matchId));
  };

  const activeMatch =
    view.name === 'live' || view.name === 'scorecard'
      ? matches.find((m) => m.id === view.matchId) || null
      : null;

  const isTopLevelTab =
    view.name === 'home' ||
    view.name === 'teams' ||
    view.name === 'tournaments' ||
    view.name === 'history';

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}

      {/* 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-black/95 backdrop-blur-md border-b border-white/15">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => navigateTo({ name: 'home' })}
            className="focus:outline-none whitespace-nowrap shrink-0"
            aria-label="CRIC X Home"
          >
            <CricXLogo size="sm" />
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-400">
            {(
              [
                { name: 'home', label: 'Home' },
                { name: 'teams', label: 'Teams' },
                { name: 'tournaments', label: 'Tournaments' },
                { name: 'history', label: 'History' },
              ] as const
            ).map((item) => {
              const active = view.name === item.name;
              return (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => navigateTo({ name: item.name })}
                  className={`whitespace-nowrap shrink-0 py-1 transition ${
                    active ? 'text-white underline underline-offset-8' : 'hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
            <button
              type="button"
              onClick={() => setGuideOpen(true)}
              className="min-h-[40px] px-3 rounded-lg border border-white/20 text-white text-xs font-medium hover:bg-white/10 transition whitespace-nowrap shrink-0"
            >
              Backup & App
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main
        className={`flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 pt-5 ${
          isTopLevelTab ? 'pb-24 md:pb-10' : 'pb-8'
        }`}
      >
        {view.name === 'home' && (
          <HomeView
            matches={matches}
            teams={teams}
            tournaments={tournaments}
            onStartFormat={(fmt) => navigateTo({ name: 'setup', format: fmt })}
            onOpenTournament={() => navigateTo({ name: 'tournaments' })}
            onResumeMatch={(id) => navigateTo({ name: 'live', matchId: id })}
            onViewScorecard={(id) => navigateTo({ name: 'scorecard', matchId: id })}
            onOpenTeams={() => navigateTo({ name: 'teams' })}
            onOpenHistory={() => navigateTo({ name: 'history' })}
          />
        )}

        {view.name === 'teams' && (
          <TeamManagerView teams={teams} onSaveTeams={handleSaveTeams} />
        )}

        {view.name === 'tournaments' && (
          <TournamentView
            tournaments={tournaments}
            teams={teams}
            matches={matches}
            onSaveTournaments={handleSaveTournaments}
            onStartFixtureMatch={(tourneyId, fixtureId, match) => {
              handleUpdateMatch(match);
              const nextTourneys = tournaments.map((t) =>
                t.id === tourneyId
                  ? {
                      ...t,
                      fixtures: t.fixtures.map((f) =>
                        f.id === fixtureId
                          ? { ...f, matchId: match.id, status: 'in_progress' as const }
                          : f
                      ),
                    }
                  : t
              );
              handleSaveTournaments(nextTourneys);
              navigateTo({ name: 'live', matchId: match.id });
            }}
            onResumeMatch={(id) => navigateTo({ name: 'live', matchId: id })}
            onViewScorecard={(id) => navigateTo({ name: 'scorecard', matchId: id })}
          />
        )}

        {view.name === 'history' && (
          <HistoryView
            matches={matches}
            onResumeMatch={(id) => navigateTo({ name: 'live', matchId: id })}
            onViewScorecard={(id) => navigateTo({ name: 'scorecard', matchId: id })}
            onDeleteMatch={handleDeleteMatch}
          />
        )}

        {view.name === 'setup' && (
          <MatchSetupView
            initialFormat={view.format}
            teams={teams}
            onSaveTeams={handleSaveTeams}
            onStartMatch={(match) => {
              handleUpdateMatch(match);
              navigateTo({ name: 'live', matchId: match.id });
            }}
            onBack={() => navigateTo({ name: 'home' })}
          />
        )}

        {view.name === 'live' && activeMatch && (
          <LiveScoringView
            match={activeMatch}
            onUpdateMatch={handleUpdateMatch}
            onOpenScorecard={() =>
              navigateTo({ name: 'scorecard', matchId: activeMatch.id })
            }
            onExit={() => navigateTo({ name: 'home' })}
          />
        )}

        {view.name === 'scorecard' && activeMatch && (
          <ScorecardView
            match={activeMatch}
            onUpdateMatch={handleUpdateMatch}
            onResumeScoring={() =>
              navigateTo({ name: 'live', matchId: activeMatch.id })
            }
            onBack={() => navigateTo({ name: 'history' })}
          />
        )}
      </main>

      {/* Mobile Bottom Tab Bar (Thumb-Zone Navigation on top-level tabs) */}
      {isTopLevelTab && (
        <nav
          aria-label="Primary Mobile Navigation"
          className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black/95 backdrop-blur-md border-t border-white/15 pb-safe"
        >
          <div className="grid grid-cols-4 h-16 items-center">
            {(
              [
                { name: 'home', label: 'Home', Icon: Home },
                { name: 'teams', label: 'Teams', Icon: Users },
                { name: 'tournaments', label: 'Events', Icon: Trophy },
                { name: 'history', label: 'History', Icon: History },
              ] as const
            ).map(({ name, label, Icon }) => {
              const active = view.name === name;
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => navigateTo({ name })}
                  className={`min-h-[48px] flex flex-col items-center justify-center gap-1 transition ${
                    active ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-[11px] font-medium tracking-tight">{label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      <OfflineGuideModal
        open={guideOpen}
        onClose={() => setGuideOpen(false)}
        onDataImported={(payload) => {
          setTeams(payload.teams);
          setMatches(payload.matches);
          setTournaments(payload.tournaments);
        }}
      />
    </div>
  );
}
