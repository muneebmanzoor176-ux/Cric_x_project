# CRIC X — Complete Offline Cricket Scorer

## Option 1: Build APK via GitHub Actions (Automatic)
1. Push this project to GitHub (includes `.github/workflows/build-apk.yml` and `CRICX-Android/gradlew`).
2. Open the **Actions** tab in your GitHub repository -> **Build CRIC X Android APK**.
3. Download the **CRIC-X-debug-apk** artifact once the workflow completes.

## Option 2: Build APK Locally in Android Studio
1. Open **Android Studio** -> **Open** -> select the `CRICX-Android/` folder.
2. Build APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)** or **./gradlew assembleDebug** inside `CRICX-Android/`.

## Option 3: Instant Android PWA Installation
Open the live CRIC X web app in Chrome on Android and tap **Install App** (or Chrome Menu -> **Add to Home screen**).
